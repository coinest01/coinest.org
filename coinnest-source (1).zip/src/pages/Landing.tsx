import { useEffect } from "react";
import { useQuery } from "convex/react";
import { Link } from "react-router";
import { motion, type Variants } from "framer-motion";
import {
  ArrowRight,
  Check,
  Clock,
  Coins,
  Database,
  Flame,
  KeyRound,
  LineChart,
  Lock,
  PiggyBank,
  ShieldCheck,
  Sparkles,
  Target,
  TrendingUp,
} from "lucide-react";
import { api } from "@/convex/_generated/api";

import { Button } from "@/components/ui/button";
import { LogoWordmark } from "@/components/logo";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { formatUSD } from "@/lib/format";

const fadeUp: Variants = {
  hidden: { opacity: 0, y: 24 },
  show: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] },
  },
};

const stagger: Variants = {
  hidden: {},
  show: { transition: { staggerChildren: 0.08 } },
};

function StatsStrip() {
  const stats = useQuery(api.savings.publicStats);
  const loading = !stats;

  const formatNumber = (n: number) => {
    if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M+`;
    if (n >= 1_000) return `${(n / 1_000).toFixed(n >= 10_000 ? 0 : 1)}k+`;
    return n.toLocaleString();
  };

  const formatCurrency = (n: number) => {
    if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(1)}M+`;
    if (n >= 1_000) return `$${formatNumber(n)}`;
    if (n > 0) return `$${n.toFixed(2)}`;
    return "$0";
  };

  const items = [
    [loading ? "—" : formatNumber(stats.totalSavingsLogged), "savings logged"],
    [loading ? "—" : formatCurrency(stats.totalTrackedUsd), "tracked by savers"],
    [loading ? "—" : `${stats.longestStreak}-day`, "longest streak"],
    ["100%", "private by design"],
  ] as const;

  return (
    <section className="border-y border-border/60 bg-muted/40">
      <div className="mx-auto grid max-w-6xl grid-cols-2 gap-8 px-4 py-10 sm:px-6 md:grid-cols-4">
        {items.map(([value, label]) => (
          <div key={label} className="text-center">
            <p className="text-2xl font-semibold tracking-tight sm:text-3xl">
              {loading ? (
                <span className="inline-block h-7 w-20 animate-pulse rounded bg-muted" />
              ) : (
                value
              )}
            </p>
            <p className="mt-1 text-sm text-muted-foreground">{label}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/5 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-primary">
      {children}
    </span>
  );
}

function Sparkline({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 200 60"
      fill="none"
      preserveAspectRatio="none"
      className={cn("h-full w-full", className)}
      aria-hidden="true"
    >
      <defs>
        <linearGradient id="sparkFill" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="var(--chart-1)" stopOpacity={0.35} />
          <stop offset="100%" stopColor="var(--chart-1)" stopOpacity={0} />
        </linearGradient>
      </defs>
      <path
        d="M0 52 C 18 48, 30 42, 44 44 S 68 34, 82 36 110 24, 126 27 152 12, 168 16 190 4, 200 6 L200 60 L0 60 Z"
        fill="url(#sparkFill)"
      />
      <path
        d="M0 52 C 18 48, 30 42, 44 44 S 68 34, 82 36 110 24, 126 27 152 12, 168 16 190 4, 200 6"
        stroke="var(--chart-1)"
        strokeWidth="2.5"
        strokeLinecap="round"
      />
    </svg>
  );
}

const features = [
  {
    icon: Coins,
    title: "Precise savings logging",
    body: "Record the USD value of any coin you set aside — BTC, ETH, SOL, USDC, and beyond — in seconds.",
  },
  {
    icon: Target,
    title: "Goal-based tracking",
    body: "Define savings goals, link each deposit to a goal, and monitor your progress with clear real-time indicators.",
  },
  {
    icon: Flame,
    title: "Consistent, measurable habits",
    body: "Daily tracking streaks reward disciplined saving and keep you on a dependable routine.",
  },
  {
    icon: LineChart,
    title: "Clear performance overview",
    body: "One focused chart shows your cumulative savings over time — no noise, just your progress.",
  },
  {
    icon: Sparkles,
    title: "Built for every saver",
    body: "An intuitive interface for newcomers and experienced holders alike. No jargon, no complexity.",
  },
  {
    icon: Lock,
    title: "Private by design",
    body: "Your financial data stays yours. Rate-limited access and server-side permissions keep it protected.",
  },
];

const steps = [
  {
    icon: KeyRound,
    title: "Create your secure account",
    body: "Sign in with your email and a one-time verification code. No password to remember, no wallet to connect.",
  },
  {
    icon: PiggyBank,
    title: "Log your savings",
    body: "Whenever you set coins aside, enter their USD value. Recording a save takes seconds.",
  },
  {
    icon: TrendingUp,
    title: "Monitor your progress",
    body: "Track cumulative totals, reach your goals, and maintain streaks — all in one dependable dashboard.",
  },
];

const security = [
  {
    icon: KeyRound,
    title: "Rate-limited authentication",
    body: "Failed sign-in attempts are capped and followed by a cooldown, making brute-force attacks impractical.",
  },
  {
    icon: ShieldCheck,
    title: "Server-side access control",
    body: "Every read and write is verified against your identity on the backend. You can only ever access your own data.",
  },
  {
    icon: Clock,
    title: "Short-lived one-time codes",
    body: "Verification codes expire within minutes, and sessions are stored securely. No shared credentials, ever.",
  },
  {
    icon: Database,
    title: "Encrypted at rest and in transit",
    body: "Your data is stored in an encrypted, per-user isolated database — secure in transit and at rest.",
  },
];

const testimonials = [
  {
    initials: "★★",
    name: "Beta tester",
    role: "Early user, v1.0",
    quote:
      "CoinNest is a brand-new app, and we're actively listening to feedback from early users like you. Your experience will shape what CoinNest becomes.",
  },
  {
    initials: "★★",
    name: "You, here first",
    role: "Community builder",
    quote:
      "Every app starts somewhere. CoinNest launched with bank-grade security, a clear privacy policy, and a real purpose: making crypto savings simple for beginners.",
  },
  {
    initials: "★★",
    name: "Future reviewer",
    role: "Waiting for you",
    quote:
      "We'd love your honest review once you've used CoinNest for a while. Real feedback from real savers is the only social proof that matters.",
  },
];

const faqs = [
  {
    q: "Is CoinNest a wallet or an exchange?",
    a: "No. CoinNest is a savings tracker. Your coins remain wherever they are — CoinNest records what you set aside, tracks your goals, and shows your progress over time. It never touches your funds.",
  },
  {
    q: "I'm new to crypto. Is this for me?",
    a: "Yes. You only need to know the USD value of what you set aside. There are no positions to manage, no charts to read, and no financial jargon.",
  },
  {
    q: "What does \u201csaved in crypto\u201d actually mean?",
    a: "Whenever you move coins into savings — a weekly buy, a bonus put into USDC, or a bit of ETH you decided not to spend — log it here. The tracker shows the USD value of everything you've set aside over time.",
  },
  {
    q: "How does the login protection work?",
    a: "Sign-in is rate-limited: after 5 failed verification attempts within an hour, the account enters a cooldown before allowing more attempts. Combined with short-lived codes, brute-force attacks are impractical.",
  },
  {
    q: "Can I delete my data?",
    a: "Always. Delete any entry or goal directly in the app, or contact us to remove your entire account and all of its data. There are no hidden copies.",
  },
];

export default function Landing() {
  // Pre-fetch the sign-in chunk once the page is idle so the next step of
  // the funnel feels instant.
  useEffect(() => {
    const timer = window.setTimeout(() => {
      import("./Auth.tsx").catch(() => {});
    }, 900);
    return () => window.clearTimeout(timer);
  }, []);

  return (
    <div className="scroll-smooth min-h-screen bg-background text-foreground">
      {/* Nav */}
      <header className="sticky top-0 z-40 border-b border-border/60 bg-background/85 backdrop-blur">
        <nav className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-4 sm:px-6">
          <Link to="/" aria-label="CoinNest home">
            <LogoWordmark markClassName="size-8" />
          </Link>
          <div className="hidden items-center gap-7 text-sm font-medium text-muted-foreground md:flex">
            <a href="#features" className="transition-colors hover:text-foreground">
              Features
            </a>
            <a href="#how" className="transition-colors hover:text-foreground">
              How it works
            </a>
            <a href="#security" className="transition-colors hover:text-foreground">
              Security
            </a>
            <a href="#faq" className="transition-colors hover:text-foreground">
              FAQ
            </a>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" asChild className="hidden sm:inline-flex">
              <Link to="/auth">Sign in</Link>
            </Button>
            <Button asChild>
              <Link to="/auth">
                Get started
                <ArrowRight className="size-4" />
              </Link>
            </Button>
          </div>
        </nav>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div
          className="pointer-events-none absolute inset-0 -z-10"
          aria-hidden="true"
        >
          <div className="absolute -top-32 left-1/2 h-[480px] w-[820px] -translate-x-1/2 rounded-full bg-gradient-to-tr from-blue-600/15 via-sky-400/10 to-transparent blur-3xl" />
        </div>
        <div className="mx-auto max-w-6xl px-4 pb-20 pt-16 sm:px-6 sm:pt-24">
          <motion.div
            variants={stagger}
            initial="hidden"
            animate="show"
            className="mx-auto max-w-3xl text-center"
          >
            <motion.div variants={fadeUp}>
              <Badge
                variant="outline"
                className="border-primary/20 bg-primary/5 px-3 py-1 text-xs font-medium text-primary"
              >
                <ShieldCheck className="mr-1.5 size-3.5" />
                Institutional-grade security · Built for every saver
              </Badge>
            </motion.div>
            <motion.h1
              variants={fadeUp}
              className="mt-6 text-4xl font-semibold leading-[1.08] tracking-tight sm:text-6xl"
            >
              Track your crypto savings{" "}
              <span className="bg-gradient-to-r from-blue-600 to-sky-500 bg-clip-text text-transparent dark:from-blue-400 dark:to-sky-300">
                with confidence.
              </span>
            </motion.h1>
            <motion.p
              variants={fadeUp}
              className="mx-auto mt-5 max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg"
            >
              CoinNest makes tracking your crypto savings simple and secure.
              Log any coin you set aside in seconds, set clear savings goals,
              and watch your progress add up — with bank-grade protection and
              full control of your data.
            </motion.p>
            <motion.div
              variants={fadeUp}
              className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row"
            >
              <Button size="lg" asChild className="w-full sm:w-auto">
                <Link to="/auth">
                  Start tracking your savings — it's free
                  <ArrowRight className="size-4" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" asChild className="w-full sm:w-auto">
                <a href="#how">See it in action</a>
              </Button>
            </motion.div>
            <motion.ul
              variants={fadeUp}
              className="mt-6 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm text-muted-foreground"
            >
              {[
                "No wallet or exchange access required",
                "Bank-grade data protection",
                "Your data, yours alone",
              ].map((item) => (
                <li key={item} className="flex items-center gap-1.5">
                  <Check className="size-4 text-primary" />
                  {item}
                </li>
              ))}
            </motion.ul>
          </motion.div>

          {/* Hero visual */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.35, ease: [0.22, 1, 0.36, 1] }}
            className="relative mx-auto mt-16 max-w-3xl sm:mt-20"
          >
            <div
              className="absolute -inset-6 -z-10 rounded-[3rem] bg-gradient-to-tr from-blue-600/15 via-sky-400/10 to-transparent blur-2xl"
              aria-hidden="true"
            />
            <div className="rounded-2xl border border-border/80 bg-card p-6 shadow-xl shadow-blue-900/5 sm:p-8">
              <div className="flex items-center justify-between gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Total savings</p>
                  <p className="mt-1 text-3xl font-semibold tracking-tight sm:text-4xl">
                    {formatUSD(1284.6)}
                  </p>
                </div>
                <span className="rounded-full bg-blue-600/10 px-2.5 py-1 text-xs font-semibold text-blue-700 dark:text-blue-300">
                  +{formatUSD(25)} this week
                </span>
              </div>
              <div className="mt-6 h-28">
                <Sparkline className="h-full w-full" />
              </div>
              <div className="mt-6 grid grid-cols-3 divide-x divide-border/70 rounded-xl border border-border/70 bg-muted/40">
                {[
                  ["This month", formatUSD(340)],
                  ["Day streak", "6 days"],
                  ["Goal: laptop", "60%"],
                ].map(([label, value]) => (
                  <div key={label} className="px-4 py-3 text-center">
                    <p className="text-[11px] uppercase tracking-wide text-muted-foreground">
                      {label}
                    </p>
                    <p className="mt-0.5 text-sm font-semibold">{value}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Floating cards */}
            <div className="absolute -left-4 -top-6 hidden rotate-[-3deg] rounded-xl border border-border/80 bg-card px-4 py-3 shadow-lg sm:block lg:-left-16">
              <p className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
                <Coins className="size-3.5 text-primary" />
                Saved in BTC
              </p>
              <p className="mt-0.5 text-sm font-semibold">+{formatUSD(25)}</p>
            </div>
            <div className="absolute -bottom-6 -right-4 hidden rotate-2 rounded-xl border border-border/80 bg-card px-4 py-3 shadow-lg sm:block lg:-right-14">
              <p className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
                <Flame className="size-3.5 text-amber-500" />
                Streak active
              </p>
              <p className="mt-0.5 text-sm font-semibold">Log today to keep it</p>
            </div>
          </motion.div>
        </div>
      </section>      {/* Stats strip */}
      <StatsStrip />

      {/* Features */}
      <section id="features" className="mx-auto max-w-6xl px-4 py-20 sm:px-6 sm:py-24">
        <motion.div
          variants={stagger}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-80px" }}
          className="mx-auto max-w-2xl text-center"
        >
          <motion.div variants={fadeUp}>
            <SectionLabel>Features</SectionLabel>
          </motion.div>
          <motion.h2
            variants={fadeUp}
            className="mt-4 text-3xl font-semibold tracking-tight sm:text-4xl"
          >
            Everything you need to track crypto savings. Nothing you don't.
          </motion.h2>
          <motion.p
            variants={fadeUp}
            className="mt-3 text-base text-muted-foreground"
          >
            Six focused features that turn "I should save more" into measurable,
            dependable progress.
          </motion.p>
        </motion.div>
        <motion.div
          variants={stagger}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-80px" }}
          className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3"
        >
          {features.map((feature) => (
            <motion.div
              key={feature.title}
              variants={fadeUp}
              className="group rounded-2xl border border-border/70 bg-card p-6 transition-all hover:-translate-y-1 hover:border-primary/25 hover:shadow-lg hover:shadow-blue-900/5"
            >
              <span className="flex size-10 items-center justify-center rounded-xl bg-primary/10 text-primary transition-transform group-hover:scale-110">
                <feature.icon className="size-5" />
              </span>
              <h3 className="mt-4 text-base font-semibold">{feature.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {feature.body}
              </p>
            </motion.div>
          ))}
        </motion.div>
      </section>

      {/* How it works */}
      <section
        id="how"
        className="border-y border-border/60 bg-muted/40 py-20 sm:py-24"
      >
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <motion.div
            variants={stagger}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: "-80px" }}
            className="mx-auto max-w-2xl text-center"
          >
            <motion.div variants={fadeUp}>
              <SectionLabel>How it works</SectionLabel>
            </motion.div>
            <motion.h2
              variants={fadeUp}
              className="mt-4 text-3xl font-semibold tracking-tight sm:text-4xl"
            >
              Three steps. Under a minute a day.
            </motion.h2>
          </motion.div>
          <motion.div
            variants={stagger}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: "-80px" }}
            className="mt-12 grid gap-4 md:grid-cols-3"
          >
            {steps.map((step, i) => (
              <motion.div
                key={step.title}
                variants={fadeUp}
                className="relative rounded-2xl border border-border/70 bg-card p-6"
              >
                <span className="absolute right-5 top-5 text-4xl font-semibold text-border">
                  {i + 1}
                </span>
                <span className="flex size-10 items-center justify-center rounded-xl bg-primary text-primary-foreground">
                  <step.icon className="size-5" />
                </span>
                <h3 className="mt-4 text-base font-semibold">{step.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  {step.body}
                </p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Security */}
      <section id="security" className="mx-auto max-w-6xl px-4 py-20 sm:px-6 sm:py-24">
        <motion.div
          variants={stagger}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-80px" }}
          className="overflow-hidden rounded-3xl bg-foreground text-background"
        >
          <div className="grid gap-10 p-8 sm:p-12 lg:grid-cols-2 lg:gap-16">
            <div>
              <span className="inline-flex items-center gap-2 rounded-full border border-background/20 bg-background/10 px-3 py-1 text-xs font-semibold uppercase tracking-wider">
                <ShieldCheck className="size-3.5" />
                Security
              </span>
              <h2 className="mt-4 text-3xl font-semibold tracking-tight sm:text-4xl">
                Your financial data, protected.
              </h2>
              <p className="mt-3 max-w-md text-sm leading-relaxed text-background/70">
                Every login is rate-limited, every read is verified against
                your identity, and your numbers are never visible to anyone but
                you.
              </p>
              <Button
                asChild
                className="mt-7 bg-background text-foreground hover:bg-background/90"
              >
                <Link to="/privacy">
                  Read the privacy policy
                  <ArrowRight className="size-4" />
                </Link>
              </Button>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              {security.map((item) => (
                <div
                  key={item.title}
                  className="rounded-2xl border border-background/15 bg-background/5 p-5"
                >
                  <item.icon className="size-5 text-background/80" />
                  <h3 className="mt-3 text-sm font-semibold">{item.title}</h3>
                  <p className="mt-1.5 text-xs leading-relaxed text-background/65">
                    {item.body}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      </section>

      {/* Why CoinNest — transparent values, not fake testimonials */}
      <section className="border-y border-border/60 bg-muted/40 py-20 sm:py-24">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <motion.div
            variants={stagger}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: "-80px" }}
            className="mx-auto max-w-2xl text-center"
          >
            <motion.div variants={fadeUp}>
              <SectionLabel>Why CoinNest</SectionLabel>
            </motion.div>
            <motion.h2
              variants={fadeUp}
              className="mt-4 text-3xl font-semibold tracking-tight sm:text-4xl"
            >
              Built honestly, from day one.
            </motion.h2>
            <motion.p
              variants={fadeUp}
              className="mt-3 text-base text-muted-foreground"
            >
              No inflated numbers. No fake testimonials. Just a real product,
              built with real security, for real savers.
            </motion.p>
          </motion.div>
          <motion.div
            variants={stagger}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: "-80px" }}
            className="mt-12 grid gap-4 md:grid-cols-3"
          >
            {testimonials.map((t) => (
              <motion.figure
                key={t.name}
                variants={fadeUp}
                className="flex flex-col rounded-2xl border border-border/70 bg-card p-6"
              >
                <span className="flex size-10 items-center justify-center rounded-xl bg-primary/10 text-primary">
                  <ShieldCheck className="size-5" />
                </span>
                <blockquote className="mt-4 flex-1 text-sm leading-relaxed text-muted-foreground">
                  {t.quote}
                </blockquote>
                <figcaption className="mt-5 flex items-center gap-3">
                  <div>
                    <p className="text-sm font-semibold">{t.name}</p>
                    <p className="text-xs text-muted-foreground">{t.role}</p>
                  </div>
                </figcaption>
              </motion.figure>
            ))}
          </motion.div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="mx-auto max-w-3xl px-4 py-20 sm:px-6 sm:py-24">
        <motion.div
          variants={stagger}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-80px" }}
          className="text-center"
        >
          <motion.div variants={fadeUp}>
            <SectionLabel>FAQ</SectionLabel>
          </motion.div>
          <motion.h2
            variants={fadeUp}
            className="mt-4 text-3xl font-semibold tracking-tight sm:text-4xl"
          >
            Questions? Answered.
          </motion.h2>
        </motion.div>
        <motion.div
          variants={fadeUp}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-80px" }}
          className="mt-10"
        >
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, i) => (
              <AccordionItem key={faq.q} value={`item-${i}`}>
                <AccordionTrigger className="text-left text-sm font-medium sm:text-base">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="text-sm leading-relaxed text-muted-foreground">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </motion.div>
      </section>

      {/* Final CTA */}
      <section className="mx-auto max-w-6xl px-4 pb-20 sm:px-6">
        <div className="relative overflow-hidden rounded-3xl border border-primary/20 bg-gradient-to-br from-primary/10 via-background to-sky-500/10 p-10 text-center sm:p-16">
          <div
            className="pointer-events-none absolute -top-24 left-1/2 h-64 w-[560px] -translate-x-1/2 rounded-full bg-blue-600/15 blur-3xl"
            aria-hidden="true"
          />
          <h2 className="relative text-3xl font-semibold tracking-tight sm:text-4xl">
            Start tracking your crypto savings today.
          </h2>
          <p className="relative mx-auto mt-3 max-w-xl text-base text-muted-foreground">
            Free to start. No wallet, no card, no risk. Verify your email and
            log your first save in under a minute.
          </p>
          <Button
            size="lg"
            asChild
            className="relative mt-8 w-full sm:w-auto"
          >
            <Link to="/auth">
              Create your free account
              <ArrowRight className="size-4" />
            </Link>
          </Button>
          <p className="relative mt-4 text-xs text-muted-foreground">
            No password needed — we email you a one-time code.
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/60 bg-muted/40">
        <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
          <div className="flex flex-col items-start justify-between gap-8 sm:flex-row">
            <div className="max-w-xs">
              <LogoWordmark markClassName="size-8" />
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                The dependable savings tracker for crypto — built for
                beginners, trusted by everyone.
              </p>
            </div>
            <div className="flex gap-16">
              <div>
                <p className="text-sm font-semibold">Product</p>
                <ul className="mt-3 grid gap-2 text-sm text-muted-foreground">
                  <li>
                    <a href="#features" className="transition-colors hover:text-foreground">
                      Features
                    </a>
                  </li>
                  <li>
                    <a href="#how" className="transition-colors hover:text-foreground">
                      How it works
                    </a>
                  </li>
                  <li>
                    <a href="#security" className="transition-colors hover:text-foreground">
                      Security
                    </a>
                  </li>
                </ul>
              </div>
              <div>
                <p className="text-sm font-semibold">Legal</p>
                <ul className="mt-3 grid gap-2 text-sm text-muted-foreground">
                  <li>
                    <Link to="/privacy" className="transition-colors hover:text-foreground">
                      Privacy policy
                    </Link>
                  </li>
                  <li>
                    <Link to="/terms" className="transition-colors hover:text-foreground">
                      Terms of Service
                    </Link>
                  </li>
                  <li>
                    <Link to="/contact" className="transition-colors hover:text-foreground">
                      Contact
                    </Link>
                  </li>
                  <li>
                    <Link to="/auth" className="transition-colors hover:text-foreground">
                      Sign in
                    </Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="mt-10 flex flex-col gap-3 border-t border-border/60 pt-6 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
            <p>© 2026 CoinNest. Secure crypto savings tracking.</p>
            <p>
              CoinNest is a savings tracker, not financial advice. Nothing here
              guarantees returns.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
