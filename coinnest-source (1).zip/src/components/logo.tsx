import { cn } from "@/lib/utils";

/**
 * CoinNest logo mark — a coin with a rising arrow on a blue tile.
 */
export function Logo({ className }: { className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center justify-center rounded-xl bg-blue-600 text-white shadow-sm",
        className,
      )}
    >
      <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth={2.1}
        strokeLinecap="round"
        strokeLinejoin="round"
        className="h-[58%] w-[58%]"
        aria-hidden="true"
      >
        <circle cx="12" cy="12" r="8.4" />
        <path d="M8.3 14.6 11.4 11.5 13.6 13.7 16.2 10.9" />
        <path d="M13.4 10.9h2.8v2.8" />
      </svg>
    </span>
  );
}

/** Wordmark with the logo mark, for navbars and footers. */
export function LogoWordmark({
  className,
  markClassName,
}: {
  className?: string;
  markClassName?: string;
}) {
  return (
    <span className={cn("inline-flex items-center gap-2.5", className)}>
      <Logo className={cn("size-9", markClassName)} />
      <span className="text-lg font-semibold tracking-tight text-foreground">
        CoinNest
      </span>
    </span>
  );
}
