// THIS FILE IS READ ONLY. Do not touch this file unless you are correctly adding a new auth provider in accordance to the vly auth documentation

import { convexAuth } from "@convex-dev/auth/server";
import { Anonymous } from "@convex-dev/auth/providers/Anonymous";
import { emailOtp } from "./auth/emailOtp";


export const { auth, signIn, signOut, store, isAuthenticated } = convexAuth({
  providers: [emailOtp, Anonymous],
  // Anti-brute-force protection: after 5 failed OTP attempts in an hour the
  // account locks for a cooldown, then allows one attempt every ~12 minutes.
  signIn: {
    maxFailedAttempsPerHour: 5,
  },
});