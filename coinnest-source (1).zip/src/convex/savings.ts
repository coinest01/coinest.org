import { getAuthUserId } from "@convex-dev/auth/server";
import { ConvexError, v } from "convex/values";
import { MutationCtx, mutation, query } from "./_generated/server";
import type { Id } from "./_generated/dataModel";
import { writeAuditLog } from "./audit";

// ---------------------------------------------------------------------------
// Validation limits
// ---------------------------------------------------------------------------

export const SAVING_LIMITS = {
  minUsd: 0.01,
  maxUsd: 1_000_000,
  assetMaxLength: 12,
  noteMaxLength: 160,
} as const;

export const GOAL_LIMITS = {
  minTarget: 1,
  maxTarget: 10_000_000,
  nameMaxLength: 60,
} as const;

export const GOAL_COLORS = [
  "blue",
  "emerald",
  "teal",
  "sky",
  "amber",
  "violet",
  "rose",
] as const;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

async function requireUserId(ctx: MutationCtx) {
  const userId = await getAuthUserId(ctx);
  if (userId === null) {
    throw new ConvexError("Please sign in to track your savings.");
  }
  return userId;
}

function roundUsd(value: number) {
  return Math.round(value * 100) / 100;
}

// Idempotency keys: a client generates one per logical action and reuses it if
// the request is retried (double-click, network drop). The server skips any
// action whose (userId, requestKey) pair already ran, so "click pay three
// times" can never create three entries.
const REQUEST_KEY_PATTERN = /^[A-Za-z0-9_-]{8,64}$/;

function isValidRequestKey(key: string | undefined) {
  return key === undefined || REQUEST_KEY_PATTERN.test(key);
}

async function alreadyProcessed(
  ctx: MutationCtx,
  table: "savings" | "goals",
  userId: Id<"users">,
  requestKey: string | undefined,
) {
  if (requestKey === undefined) {
    return false;
  }
  const existing = await ctx.db
    .query(table)
    .withIndex("by_user_requestKey", (q) =>
      q.eq("userId", userId).eq("requestKey", requestKey),
    )
    .first();
  return existing !== null;
}

// ---------------------------------------------------------------------------
// Savings
// ---------------------------------------------------------------------------

export const addSaving = mutation({
  args: {
    amountUsd: v.number(),
    asset: v.string(),
    assetAmount: v.optional(v.number()),
    note: v.optional(v.string()),
    goalId: v.optional(v.id("goals")),
    requestKey: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await requireUserId(ctx);

    if (!isValidRequestKey(args.requestKey)) {
      throw new ConvexError("Invalid request key.");
    }
    // Idempotent: if this exact submit was already recorded (retry after a
    // network drop or a double click), do nothing rather than double-count.
    if (await alreadyProcessed(ctx, "savings", userId, args.requestKey)) {
      return;
    }

    if (
      !Number.isFinite(args.amountUsd) ||
      args.amountUsd < SAVING_LIMITS.minUsd ||
      args.amountUsd > SAVING_LIMITS.maxUsd
    ) {
      throw new ConvexError(
        `Amount must be between $${SAVING_LIMITS.minUsd} and $${SAVING_LIMITS.maxUsd.toLocaleString()}.`,
      );
    }

    const asset = args.asset.trim().toUpperCase().slice(0, SAVING_LIMITS.assetMaxLength);
    if (!asset) {
      throw new ConvexError("Please choose or enter the coin you saved.");
    }

    const note = args.note?.trim().slice(0, SAVING_LIMITS.noteMaxLength) || undefined;

    const assetAmount =
      args.assetAmount !== undefined &&
      Number.isFinite(args.assetAmount) &&
      args.assetAmount > 0
        ? args.assetAmount
        : undefined;

    let goalId: typeof args.goalId;
    if (args.goalId !== undefined) {
      const goal = await ctx.db.get(args.goalId);
      if (goal === null || goal.userId !== userId) {
        throw new ConvexError("That goal doesn't exist.");
      }
      goalId = args.goalId;
    }

    await ctx.db.insert("savings", {
      userId,
      amountUsd: roundUsd(args.amountUsd),
      asset,
      assetAmount,
      note,
      goalId,
      requestKey: args.requestKey,
    });
    await writeAuditLog(ctx, userId, "saving_added", `${asset} ${roundUsd(args.amountUsd)}`);
  },
});

export const deleteSaving = mutation({
  args: { id: v.id("savings") },
  handler: async (ctx, args) => {
    const userId = await requireUserId(ctx);
    const saving = await ctx.db.get(args.id);
    if (saving === null || saving.userId !== userId) {
      throw new ConvexError("That entry doesn't exist.");
    }
    await ctx.db.delete(args.id);
    await writeAuditLog(ctx, userId, "saving_deleted", saving.asset);
  },
});

// ---------------------------------------------------------------------------
// Goals
// ---------------------------------------------------------------------------

export const createGoal = mutation({
  args: {
    name: v.string(),
    targetUsd: v.number(),
    color: v.string(),
    requestKey: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await requireUserId(ctx);

    if (!isValidRequestKey(args.requestKey)) {
      throw new ConvexError("Invalid request key.");
    }
    // Idempotent: a double-clicked "Create goal" only ever creates one.
    if (await alreadyProcessed(ctx, "goals", userId, args.requestKey)) {
      return;
    }

    const name = args.name.trim().slice(0, GOAL_LIMITS.nameMaxLength);
    if (!name) {
      throw new ConvexError("Give your goal a name.");
    }
    if (
      !Number.isFinite(args.targetUsd) ||
      args.targetUsd < GOAL_LIMITS.minTarget ||
      args.targetUsd > GOAL_LIMITS.maxTarget
    ) {
      throw new ConvexError(
        `Goal target must be between $${GOAL_LIMITS.minTarget} and $${GOAL_LIMITS.maxTarget.toLocaleString()}.`,
      );
    }
    if (!(GOAL_COLORS as readonly string[]).includes(args.color)) {
      throw new ConvexError("Pick a valid goal color.");
    }

    await ctx.db.insert("goals", {
      userId,
      name,
      targetUsd: roundUsd(args.targetUsd),
      color: args.color,
      completed: false,
      requestKey: args.requestKey,
    });
    await writeAuditLog(ctx, userId, "goal_created", name);
  },
});

export const toggleGoalComplete = mutation({
  args: { id: v.id("goals") },
  handler: async (ctx, args) => {
    const userId = await requireUserId(ctx);
    const goal = await ctx.db.get(args.id);
    if (goal === null || goal.userId !== userId) {
      throw new ConvexError("That goal doesn't exist.");
    }
    await ctx.db.patch(args.id, { completed: !goal.completed });
    await writeAuditLog(ctx, userId, "goal_completed_toggled", goal.name);
  },
});

export const deleteGoal = mutation({
  args: { id: v.id("goals") },
  handler: async (ctx, args) => {
    const userId = await requireUserId(ctx);
    const goal = await ctx.db.get(args.id);
    if (goal === null || goal.userId !== userId) {
      throw new ConvexError("That goal doesn't exist.");
    }
    // Unlink any savings entries that pointed at this goal.
    const linked = await ctx.db
      .query("savings")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .filter((q) => q.eq(q.field("goalId"), args.id))
      .collect();
    for (const saving of linked) {
      await ctx.db.patch(saving._id, { goalId: undefined });
    }
    await ctx.db.delete(args.id);
    await writeAuditLog(ctx, userId, "goal_deleted", goal.name);
  },
});

// ---------------------------------------------------------------------------
// Queries (each is scoped to the signed-in user only)
// ---------------------------------------------------------------------------

export const mySavings = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (userId === null) {
      return [];
    }
    return await ctx.db
      .query("savings")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .collect();
  },
});

export const myGoals = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (userId === null) {
      return [];
    }
    return await ctx.db
      .query("goals")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("asc")
      .collect();
  },
});

// ---------------------------------------------------------------------------
// Public aggregate stats (used by the landing page — no auth required)
// ---------------------------------------------------------------------------

export const publicStats = query({
  args: {},
  handler: async (ctx) => {
    const allSavings = await ctx.db.query("savings").collect();
    const allGoals = await ctx.db.query("goals").collect();
    const allUsers = await ctx.db.query("users").collect();

    let totalUsd = 0;
    let longestStreak = 0;

    // Aggregate totals
    for (const s of allSavings) {
      totalUsd += s.amountUsd;
    }

    // Compute longest streak across all users (simplified: group by day)
    const daysSet = new Set<string>();
    for (const s of allSavings) {
      const d = new Date(s._creationTime);
      daysSet.add(
        `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`,
      );
    }
    const sortedDays = [...daysSet].sort();
    let currentStreak = 1;
    for (let i = 1; i < sortedDays.length; i++) {
      const prev = new Date(sortedDays[i - 1]);
      const curr = new Date(sortedDays[i]);
      const diffMs = curr.getTime() - prev.getTime();
      if (diffMs === 86_400_000) {
        currentStreak += 1;
      } else {
        currentStreak = 1;
      }
      if (currentStreak > longestStreak) longestStreak = currentStreak;
    }
    if (sortedDays.length > 0 && longestStreak === 0) longestStreak = 1;

    return {
      totalSavingsLogged: allSavings.length,
      totalTrackedUsd: totalUsd,
      longestStreak,
      totalUsers: allUsers.length,
      totalGoals: allGoals.length,
    };
  },
});

// ---------------------------------------------------------------------------
// Export user data (GDPR compliance — returns structured data for CSV)
// ---------------------------------------------------------------------------

export const exportData = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (userId === null) {
      return null;
    }

    const savings = await ctx.db
      .query("savings")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();

    const goals = await ctx.db
      .query("goals")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();

    const user = await ctx.db.get(userId);

    return {
      user: {
        name: user?.name,
        email: user?.email,
        createdAt: user?._creationTime,
      },
      savings: savings.map((s) => ({
        date: new Date(s._creationTime).toISOString(),
        asset: s.asset,
        amountUsd: s.amountUsd,
        assetAmount: s.assetAmount,
        note: s.note,
      })),
      goals: goals.map((g) => ({
        name: g.name,
        targetUsd: g.targetUsd,
        completed: g.completed,
      })),
      exportedAt: new Date().toISOString(),
    };
  },
});
