import { authTables } from "@convex-dev/auth/server";
import { defineSchema, defineTable } from "convex/server";
import { Infer, v } from "convex/values";

// default user roles. can add / remove based on the project as needed
export const ROLES = {
  ADMIN: "admin",
  USER: "user",
  MEMBER: "member",
} as const;

export const roleValidator = v.union(
  v.literal(ROLES.ADMIN),
  v.literal(ROLES.USER),
  v.literal(ROLES.MEMBER),
);
export type Role = Infer<typeof roleValidator>;

const schema = defineSchema(
  {
    // default auth tables using convex auth.
    ...authTables, // do not remove or modify

    // the users table is the default users table that is brought in by the authTables
    users: defineTable({
      name: v.optional(v.string()), // name of the user. do not remove
      image: v.optional(v.string()), // image of the user. do not remove
      email: v.optional(v.string()), // email of the user. do not remove
      emailVerificationTime: v.optional(v.number()), // email verification time. do not remove
      isAnonymous: v.optional(v.boolean()), // is the user anonymous. do not remove

      role: v.optional(roleValidator), // role of the user. do not remove
      isPremium: v.optional(v.boolean()), // premium entitlement (used when pricing launches)
    }).index("email", ["email"]), // index for the email. do not remove or modify

    // ------------------------------------------------------------------
    // Savings tracker tables (CoinNest)
    // ------------------------------------------------------------------

    // A single savings entry: the USD value a user set aside, in any coin.
    savings: defineTable({
      userId: v.id("users"),
      amountUsd: v.number(), // USD value of what was saved
      asset: v.string(), // e.g. "BTC", "ETH", "SOL", "USDC", "USD"
      assetAmount: v.optional(v.number()), // optional quantity of the asset
      note: v.optional(v.string()), // optional note (e.g. "weekly DCA")
      goalId: v.optional(v.id("goals")), // optional goal this save counts toward
      requestKey: v.optional(v.string()), // idempotency key — a retried/double-clicked submit reuses it and is deduped
    }).index("by_user", ["userId"]).index("by_user_requestKey", ["userId", "requestKey"]),

    // A savings goal the user is working toward.
    goals: defineTable({
      userId: v.id("users"),
      name: v.string(), // goal name, e.g. "New laptop"
      targetUsd: v.number(), // savings target in USD
      color: v.string(), // accent color key for the progress bar
      completed: v.boolean(), // whether the goal has been reached
      requestKey: v.optional(v.string()), // idempotency key — dedupes double-submits
    }).index("by_user", ["userId"]).index("by_user_requestKey", ["userId", "requestKey"]),

    // Server-side access log: records sign-in/sign-out and data changes so
    // account activity can be reviewed. Written only by authenticated code.
    auditLogs: defineTable({
      userId: v.id("users"),
      event: v.string(), // e.g. "login", "logout", "saving_added", "goal_created"
      detail: v.optional(v.string()), // optional context (e.g. sign-in method)
    }).index("by_user", ["userId"]),

    // Daily usage counters for the AI Coach and Meme Signal board, so the
    // premium entitlement (10 uses/day) is enforced server-side, not in the UI.
    aiUsage: defineTable({
      userId: v.id("users"),
      date: v.string(), // YYYY-MM-DD local day
      coachCount: v.number(), // AI Coach requests used today
      signalsCount: v.number(), // Signal board refreshes used today
    }).index("by_user_date", ["userId", "date"]),

    // Per-request log of every AI call: which prompt produced which result, how
    // many tokens it cost, and how long it took. This is the "track cost per
    // request / monitor wrong answers" requirement from the ops playbook.
    aiCalls: defineTable({
      userId: v.id("users"),
      kind: v.string(), // "coach" | "signals"
      prompt: v.optional(v.string()), // the question sent (capped)
      model: v.optional(v.string()), // model used, e.g. "sonar"
      tokensIn: v.optional(v.number()),
      tokensOut: v.optional(v.number()),
      costUsd: v.optional(v.number()), // estimated cost of this request
      latencyMs: v.optional(v.number()),
    }).index("by_user", ["userId"]),
  },
  {
    schemaValidation: false,
  },
);

export default schema;
