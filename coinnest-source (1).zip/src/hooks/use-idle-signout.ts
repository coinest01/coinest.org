import { useEffect, useRef } from "react";
import { useNavigate } from "react-router";
import { toast } from "sonner";
import { useAuth } from "@/hooks/use-auth";

// After this long without any activity, the session is ended for security.
const IDLE_MS = 30 * 60 * 1000; // 30 minutes
const CHECK_INTERVAL_MS = 30 * 1000; // re-check every 30s

/**
 * Auto sign-out ("session lock") for signed-in pages: if the user is inactive
 * for 30 minutes, end their session and send them back to the sign-in page.
 */
export function useIdleSignout() {
  const { signOut } = useAuth();
  const navigate = useNavigate();
  const lastActivityRef = useRef(Date.now());
  const signedOutRef = useRef(false);

  useEffect(() => {
    const lockout = async () => {
      if (signedOutRef.current) return;
      signedOutRef.current = true;
      try {
        await signOut();
      } catch {
        // session may already be gone — still redirect below
      }
      toast("Signed out for security", {
        description:
          "You were inactive for 30 minutes, so we ended your session. Sign back in anytime.",
      });
      navigate("/auth?returnTo=/dashboard");
    };

    const bump = () => {
      lastActivityRef.current = Date.now();
    };

    const onVisibilityChange = () => {
      if (
        document.visibilityState === "visible" &&
        Date.now() - lastActivityRef.current > IDLE_MS
      ) {
        void lockout();
      }
    };

    const events = ["pointerdown", "keydown", "scroll", "touchstart"] as const;
    events.forEach((event) =>
      window.addEventListener(event, bump, { passive: true }),
    );
    document.addEventListener("visibilitychange", onVisibilityChange);

    const timer = window.setInterval(() => {
      if (Date.now() - lastActivityRef.current > IDLE_MS) {
        void lockout();
      }
    }, CHECK_INTERVAL_MS);

    return () => {
      window.clearInterval(timer);
      events.forEach((event) => window.removeEventListener(event, bump));
      document.removeEventListener("visibilitychange", onVisibilityChange);
    };
  }, [signOut, navigate]);
}
